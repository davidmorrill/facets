from facets.ui.image     import ImageInfo
from facets.ui.ui_facets import Margin, Border

images = [
    ImageInfo(
        name        = 'AnimationLab',
        image_name  = '@demo:AnimationLab',
        description = '',
        category    = 'General',
        keywords    = [],
        width       = 594,
        height      = 472,
        border      = Border( 0, 0, 0, 0 ),
        content     = Margin( 0, 0, 0, 0 ),
        label       = Margin( 0, 0, 0, 0 ),
        alignment   = 'default'
    ),
    ImageInfo(
        name        = 'Equations',
        image_name  = '@demo:Equations',
        description = '',
        category    = 'General',
        keywords    = [],
        width       = 610,
        height      = 512,
        border      = Border( 0, 0, 0, 0 ),
        content     = Margin( 0, 0, 0, 0 ),
        label       = Margin( 0, 0, 0, 0 ),
        alignment   = 'default'
    ),
    ImageInfo(
        name        = 'Facets_ico_11',
        image_name  = '@demo:Facets_ico_11',
        description = '',
        category    = 'General',
        keywords    = [],
        width       = 512,
        height      = 512,
        border      = Border( 0, 0, 0, 0 ),
        content     = Margin( 0, 0, 0, 0 ),
        label       = Margin( 0, 0, 0, 0 ),
        alignment   = 'default'
    ),
    ImageInfo(
        name        = 'Facets_logo',
        image_name  = '@demo:Facets_logo',
        description = '',
        category    = 'General',
        keywords    = [],
        width       = 512,
        height      = 512,
        border      = Border( 0, 0, 0, 0 ),
        content     = Margin( 0, 0, 0, 0 ),
        label       = Margin( 0, 0, 0, 0 ),
        alignment   = 'default'
    ),
    ImageInfo(
        name        = 'Facets_power',
        image_name  = '@demo:Facets_power',
        description = '',
        category    = 'General',
        keywords    = [],
        width       = 512,
        height      = 512,
        border      = Border( 0, 0, 0, 0 ),
        content     = Margin( 0, 0, 0, 0 ),
        label       = Margin( 0, 0, 0, 0 ),
        alignment   = 'default'
    ),
    ImageInfo(
        name        = 'FilmstripEditorTest',
        image_name  = '@demo:FilmstripEditorTest',
        description = '',
        category    = 'General',
        keywords    = [],
        width       = 512,
        height      = 528,
        border      = Border( 0, 0, 0, 0 ),
        content     = Margin( 0, 0, 0, 0 ),
        label       = Margin( 0, 0, 0, 0 ),
        alignment   = 'default'
    ),
    ImageInfo(
        name        = 'Particles',
        image_name  = '@demo:Particles',
        description = '',
        category    = 'General',
        keywords    = [],
        width       = 548,
        height      = 512,
        border      = Border( 0, 0, 0, 0 ),
        content     = Margin( 0, 0, 0, 0 ),
        label       = Margin( 0, 0, 0, 0 ),
        alignment   = 'default'
    ),
    ImageInfo(
        name        = 'Twixter',
        image_name  = '@demo:Twixter',
        description = '',
        category    = 'General',
        keywords    = [],
        width       = 571,
        height      = 512,
        border      = Border( 0, 0, 0, 0 ),
        content     = Margin( 0, 0, 0, 0 ),
        label       = Margin( 0, 0, 0, 0 ),
        alignment   = 'default'
    ),
    ImageInfo(
        name        = 'WebColorPicker',
        image_name  = '@demo:WebColorPicker',
        description = '',
        category    = 'General',
        keywords    = [],
        width       = 510,
        height      = 468,
        border      = Border( 0, 0, 0, 0 ),
        content     = Margin( 0, 0, 0, 0 ),
        label       = Margin( 0, 0, 0, 0 ),
        alignment   = 'default'
    )
]