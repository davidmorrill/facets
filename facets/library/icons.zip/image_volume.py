from facets.ui.image import ImageVolume, ImageVolumeInfo

volume = ImageVolume(
    category = 'General',
    keywords = [],
    aliases  = [],
    info     = [
        ImageVolumeInfo(
            description = 'No volume description specified.',
            copyright   = 'No copyright information specified.',
            license     = 'No license information specified.',
            image_names = []
        )
    ]
)