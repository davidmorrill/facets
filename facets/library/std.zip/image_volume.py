from facets.ui.image import ImageVolume, ImageVolumeInfo

volume = ImageVolume(
    category = 'General',
    keywords = [],
    aliases  = [],
    info     = [
        ImageVolumeInfo(
            description = 'Standard Facets UI Icons and Themes.',
            copyright   = 'Copyright (c) 2008 by David C. Morrill\nAll rights reserved.',
            license     = 'This software is provided without warranty under the terms of the BSD\nlicense included in facets/LICENSE.txt and may be redistributed only\nunder the conditions described in the aforementioned license.',
            image_names = []
        )
    ]
)