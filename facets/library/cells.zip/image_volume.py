from facets.ui.image import ImageVolume, ImageVolumeInfo

volume = ImageVolume(
    category = 'Themes',
    keywords = [],
    aliases  = [],
    info     = [
        ImageVolumeInfo(
            description = 'A collection of images suitable for use as Facets UI GridEditor cell themes.\nAll images created by: David C. Morrill.',
            copyright   = 'Copyright (c) 2009, David C. Morrill. All rights reserved.',
            license     = '',
            image_names = []
        )
    ]
)